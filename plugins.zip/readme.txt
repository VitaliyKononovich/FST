On Windows:

The personal plugin folder is %APPDATA%\Roaming\Wireshark\plugins.
The global plugin folder is WIRESHARK\plugins.

On Unix-like systems:

The personal plugin folder is ~/.local/lib/wireshark/plugins.