local umts_rrc_dl_dcch = Proto("RRC_DL_DCCH", "UMTS RRC DL DCCH")
local umts_rrc_dl_ccch = Proto("RRC_DL_CCCH", "UMTS RRC DL CCCH")
local umts_rrc_ul_dcch = Proto("RRC_UL_DCCH", "UMTS RRC UL DCCH")
local umts_rrc_ul_ccch = Proto("RRC_UL_CCCH", "UMTS RRC UL CCCH")
local umts_rrc_bcch_fach = Proto("RRC_BCCH_FACH", "UMTS RRC BCCH FACH")
local umts_rnsap = Proto("IUR_RNSAP", "IUR RNSAP")
local umts_rrc_pcch = Proto("RRC_PCCH", "UMTS RRC PCCH")

function umts_rrc_dl_dcch.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_dl_dcch.name
	local dissector = Dissector.get("rrc.dl.dcch")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rrc_dl_ccch.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_dl_ccch.name
	local dissector = Dissector.get("rrc.dl.ccch")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rrc_ul_dcch.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_ul_dcch.name
	local dissector = Dissector.get("rrc.ul.dcch")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rrc_ul_ccch.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_ul_ccch.name
	local dissector = Dissector.get("rrc.ul.ccch")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rrc_bcch_fach.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_bcch_fach.name
	local dissector = Dissector.get("rrc.bcch.fach")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rnsap.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rnsap.name
	local dissector = Dissector.get("rnsap")
	dissector:call(buffer, pinfo, tree) 
end

function umts_rrc_pcch.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = umts_rrc_pcch.name
	local dissector = Dissector.get("rrc.pcch")
	dissector:call(buffer, pinfo, tree) 
end


local udp_encap_table = DissectorTable.get("udp.port")
udp_encap_table:add(5000, umts_rrc_dl_dcch)
udp_encap_table:add(5001, umts_rrc_dl_ccch)
udp_encap_table:add(5002, umts_rrc_ul_dcch)
udp_encap_table:add(5003, umts_rrc_ul_ccch)
udp_encap_table:add(5004, umts_rrc_bcch_fach)
udp_encap_table:add(5005, umts_rnsap)
udp_encap_table:add(5006, umts_rrc_pcch)



local gsm_abis = Proto("Abis", "GSM Abis")
local gsm_rlc_up = Proto("RLC_MAC_UP", "GSM RLC-MAC-UP")
local gsm_rlc_down = Proto("RLC_MAC_DOWN", "GSM RLC-MAC-DOWN")
local gsm_llc = Proto("LLC_", "GSM LLC")

function gsm_abis.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = gsm_abis.name
	local dissector = Dissector.get("gsm_abis_rsl")
	dissector:call(buffer, pinfo, tree) 
end

function gsm_rlc_up.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = gsm_rlc_up.name
	local dissector = Dissector.get("gsm_rlcmac_ul")
	dissector:call(buffer, pinfo, tree) 
end

function gsm_rlc_down.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = gsm_rlc_down.name
	local dissector = Dissector.get("gsm_rlcmac_dl")
	dissector:call(buffer, pinfo, tree) 
end

function gsm_llc.dissector(buffer, pinfo, tree)
	length = buffer:len()
	if length == 0 then return end

	pinfo.cols.protocol = gsm_llc.name
	local dissector = Dissector.get("llcgprs")
	dissector:call(buffer, pinfo, tree) 
end

udp_encap_table:add(5100, gsm_abis)
udp_encap_table:add(5102, gsm_rlc_up)
udp_encap_table:add(5103, gsm_rlc_down)
udp_encap_table:add(5104, gsm_llc)
